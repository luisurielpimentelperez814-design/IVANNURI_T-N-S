package com.ivanna.fusion.pro
import android.media.*
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
 private var audioRecord: AudioRecord? = null
 private var sampleRateReal by mutableStateOf(48000)

 override fun onCreate(savedInstanceState: Bundle?) {
  super.onCreate(savedInstanceState)
  val projManager = getSystemService(MediaProjectionManager::class.java)
  val launcher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { /* iniciar captura */ }

  setContent {
   var drive by remember { mutableStateOf(2.0f) }
   var mix by remember { mutableStateOf(0.8f) }
   var master by remember { mutableStateOf(0.95f) }
   val calibrator = remember { AiCalibrator() }
   val scope = rememberCoroutineScope()

   MaterialTheme {
    Column(Modifier.padding(16.dp)) {
     Text(if(sampleRateReal>=96000) "32-bit float • 96kHz REAL ✓" else "32-bit float • 48kHz", style = MaterialTheme.typography.titleMedium)
     Spacer(Modifier.height(8.dp))
     Button(onClick={ launcher.launch(projManager.createScreenCaptureIntent()) }) { Text("INICIAR CAPTURA") }
     Spacer(Modifier.height(16.dp))
     Text("DRIVE: ${"%.2f".format(drive)}"); Slider(value=drive, onValueChange={drive=it}, valueRange=0f..5f)
     Text("MIX: ${"%.2f".format(mix)}"); Slider(value=mix, onValueChange={mix=it}, valueRange=0f..1f)
     Text("MASTER: ${"%.2f".format(master)}"); Slider(value=master, onValueChange={master=it}, valueRange=0f..1.5f)
     Spacer(Modifier.height(16.dp))
     Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
      Button(onClick={drive=2.2f; mix=0.8f; master=0.95f}){Text("Grand Funk")}
      Button(onClick={drive=1.8f; mix=0.7f; master=0.9f}){Text("Zeppelin")}
      Button(onClick={drive=2.8f; mix=0.85f; master=1.0f}){Text("Deep Purple")}
     }
     Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
      Button(onClick={drive=1.6f; mix=0.75f; master=0.92f}){Text("Rush")}
      Button(onClick={drive=3.0f; mix=0.9f; master=1.0f}){Text("Budgie")}
     }
     Spacer(Modifier.height(8.dp))
     Button(onClick={ scope.launch { val p = calibrator.calibrar(AudioContext("zeppelin",drive,mix,0.5f)); drive=p.drive; mix=p.mix; master=p.master } }) { Text("IA CALIBRAR") }
    }
   }
  }
 }

 private fun crearCaptura(): AudioRecord {
  val rates = listOf(96000,48000)
  for(rate in rates){
   val fmt = AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_FLOAT).setSampleRate(rate).setChannelMask(AudioFormat.CHANNEL_IN_STEREO).build()
   val size = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_STEREO, AudioFormat.ENCODING_PCM_FLOAT)
   if(size>0){ val rec = AudioRecord.Builder().setAudioFormat(fmt).setBufferSizeInBytes(size*4).build(); if(rec.state==AudioRecord.STATE_INITIALIZED){ sampleRateReal=rec.sampleRate; return rec } }
  }
  throw RuntimeException("No float")
 }
}
