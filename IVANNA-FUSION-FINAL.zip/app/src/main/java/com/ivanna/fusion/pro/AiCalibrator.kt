package com.ivanna.fusion.pro
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

data class AudioContext(val banda: String, val drive: Float, val mix: Float, val rms: Float)
data class Preset(val drive: Float, val mix: Float, val master: Float, val eq: List<Float>, val funcion: String)

class AiCalibrator(private val endpoint: String = "http://192.168.1.100:5000/calibrar") {
 suspend fun calibrar(ctx: AudioContext): Preset = withContext(Dispatchers.IO) {
  val json = JSONObject().apply { put("banda", ctx.banda); put("drive", ctx.drive); put("mix", ctx.mix); put("rms", ctx.rms) }
  val conn = (URL(endpoint).openConnection() as HttpURLConnection).apply { requestMethod="POST"; doOutput=true; setRequestProperty("Content-Type","application/json") }
  conn.outputStream.write(json.toString().toByteArray())
  val resp = JSONObject(conn.inputStream.bufferedReader().readText())
  Preset(resp.getDouble("drive").toFloat(), resp.getDouble("mix").toFloat(), resp.getDouble("master").toFloat(), List(10){i->resp.getJSONArray("eq").getDouble(i).toFloat()}, resp.getString("funcion"))
 }
}
