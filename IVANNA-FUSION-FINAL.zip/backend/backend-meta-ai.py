from flask import Flask, request, jsonify
import math
app = Flask(__name__)

def sat(banda, x, d):
 if banda=="grandfunk": y=x*(1+d); return y/(1+abs(y))+0.08*y*y
 if banda=="zeppelin": return math.tanh(x*d*1.8)*(0.7+0.3*math.cos(x*3))
 if banda=="deeppurple": y=x*d*2.5; return y/math.sqrt(1+y*y)
 if banda=="rush": return x*0.6+math.tanh(x*d*1.2)*0.4+0.05*math.sin(x*12)
 if banda=="budgie": y=x*d*3; return y/(1+abs(y)**1.5)*0.9+0.1*math.tanh(y*5)
 return x

EQ = {
 "grandfunk":[3,2,0,-1,-2,0,2,3,4,3],
 "zeppelin":[2,1,0,0,-1,1,3,4,3,2],
 "deeppurple":[4,3,1,0,-2,0,2,4,5,4],
 "rush":[1,0,-1,-1,0,2,3,4,2,1],
 "budgie":[5,3,0,-3,-2,1,2,3,3,2]
}

@app.post("/calibrar")
def calibrar():
 data=request.json; banda=data.get("banda","zeppelin")
 return jsonify(drive=data.get("drive",2.0), mix=0.8, master=0.95, eq=EQ[banda], funcion=f"sat_{banda}")

app.run(host="0.0.0.0", port=5000)
